<?php
session_start();
include('include/config.php');
//if(strlen($_SESSION['alogin'])==0)
//	{	
//header('location:index.php');
//}
//else{
	
if(isset($_POST['submit']))
{
	$category=$_POST['category'];

	$productname=$_POST['productName'];
	$productcompany=$_POST['productCompany'];
	$productprice=$_POST['productprice'];
	$productpricebd=$_POST['productpricebd'];
	$securitycharge=$_POST['securitycharge'];
	$productdescription=$_POST['productDescription'];
	$quantity=$_POST['quantity'];
	$productavailability=$_POST['productAvailability'];
	$productimage1=$_FILES["productimage1"]["name"];
	$productimage2=$_FILES["productimage2"]["name"];
	$productimage3=$_FILES["productimage3"]["name"];
//for getting product id
$query=mysqli_query($con,"select max(id) as id from products");

	$result=mysqli_fetch_array($query);
	 $productid=$result['id']+1;
	echo"<script>alert('$productid')</script>";
	$dir="productimages/$productid";
	mkdir($dir);// directory creation for product images
	move_uploaded_file($_FILES["productimage1"]["tmp_name"],"productimages/$productid/".$_FILES["productimage1"]["name"]);
	move_uploaded_file($_FILES["productimage2"]["tmp_name"],"productimages/$productid/".$_FILES["productimage2"]["name"]);
	move_uploaded_file($_FILES["productimage3"]["tmp_name"],"productimages/$productid/".$_FILES["productimage3"]["name"]);
$sql=mysqli_query($con,"insert into products(`category`, `productName`, `productCompany`, `productPrice`, `productPriceBeforeDiscount`, `securitycharge`, `productDescription`, `productImage1`, `productImage2`, `productImage3`, `quantity`, `productAvailability`) values('$category','$productname','$productcompany','$productprice','$productpricebd','$securitycharge','$productdescription','$productimage1','$productimage2','$productimage3','$quantity','$productavailability')");
$_SESSION['msg']="Product Inserted Successfully !!";

}
//}


?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="style.css">

	<title>AdminHub</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-building-house'></i>
			<span class="text">Rentsho-Master</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="home.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Admin Dashboard</span>
				</a>
			</li>
            <li>
				<a href="change-password.php">
					<i class='bx bxs-user-circle' ></i>
					<span class="text">Order Management</span>
				</a>
			</li>
            
			<li>
				<a href="manage-users.php">
					<i class='bx bxs-user-circle' ></i>
					<span class="text">Manage Users</span>
				</a>
			</li>
            <li>
				<a href="category.php">
					<i class='bx bx-arch' ></i>
					<span class="text">Create Categories</span>
				</a>
			</li>
			<!-- <li>
				<a href="subcategory.php">
					<i class='bx bx-arch' ></i>
					<span class="text">Sub Categories</span>
				</a>
			</li> -->
			<li>
				<a href="insert-product.php">
					<i class='bx bxs-traffic-cone' ></i>
					<span class="text">Insert Product</span>
				</a>
			</li>
			<!-- <li>
				<a href="manage-product.php">
					<i class='bx bxs-message-dots' ></i>
					<span class="text">Manage product</span>
				</a>
			</li> -->
            <li>
				<a href="ArcRec.php">
					<i class='bx bx-arch' ></i>
					<span class="text">Lender Management</span>
				</a>
			</li>
           

			<li>
			<li>
		</ul>
		<ul class="side-menu">
			</li>
			<li>
				<a href="logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<!-- <a href="#" class="nav-link">Categories</a> -->
			<form action="#">
				<div class="form-input">
					<input type="search" placeholder="Search...">
					<button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
				</div>
			</form>
			<input type="checkbox" id="switch-mode" hidden>
			<label for="switch-mode" class="switch-mode"></label>
			<!--<a href="#" class="notification">
				<i class='bx bxs-bell' ></i>
				<span class="num">8</span>
			</a>-->
			
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Dashboard </h1>
					<ul class="breadcrumb">
						<li>
							<a href="home.php">Dashboard</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="home.php">Home</a>
						</li>
					</ul>
				</div>
				<!-- <a href="#" class="btn-download"> 
					<i class='bx bxs-cloud-download' ></i>
					<span class="text">Download PDF</span>
				</a> -->
			</div>
            
			
                  <div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Insert Products</h3>
					</div>
							<div class="module-body">

									<?php if(isset($_POST['submit']))
{?>
									<div class="alert alert-success">
										<button type="button" class="close" data-dismiss="alert">×</button>
									<strong>Well done!</strong>	<?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?>
									</div>
<?php } ?>


									<?php if(isset($_GET['del']))
{?>
									<div class="alert alert-error">
										<button type="button" class="close" data-dismiss="alert">×</button>
									<strong>Oh snap!</strong> 	<?php echo htmlentities($_SESSION['delmsg']);?><?php echo htmlentities($_SESSION['delmsg']="");?>
									</div>
<?php } ?>

									<br />

			<form class="form-horizontal row-fluid" name="insertproduct" method="post" enctype="multipart/form-data">
			<link rel="stylesheet" href="s1.css">
<div class="control-group">
<label class="control-label" for="basicinput">Category</label>
<div class="controls">
<select name="category" class="span8 tip" onChange="getSubcat(this.value);"  required>

<?php $query=mysqli_query($con,"select * from category");
while($row=mysqli_fetch_array($query))
{?>

<option value="<?php echo $row['id'];?>"><?php echo $row['categoryName'];?></option>
<?php } ?>
</select>
</div>
</div>




<div class="control-group">
<label class="control-label" for="basicinput">Product Name</label>
<div class="controls">
<input type="text"    name="productName"  placeholder="Enter Product Name" class="span8 tip" required>
</div>
</div>

<div class="control-group">
<label class="control-label" for="basicinput">Product Company</label>
<div class="controls">
<input type="text"    name="productCompany"  placeholder="Enter Product Comapny Name" class="span8 tip" required maxlength="10">
</div>
</div>
<div class="control-group">
<label class="control-label" for="basicinput">Product Price </label>
<div class="controls">
<input type="text"    name="productpricebd"  placeholder="Enter Product Price" class="span8 tip" required maxlength="5">
</div>
</div>

<div class="control-group">
<label class="control-label" for="basicinput">Total price(adding security charge)</label>
<div class="controls">
<input type="text"    name="productprice"  placeholder="Enter Product Price" class="span8 tip" required maxlength="5">
</div>
</div>

<div class="control-group">
<label class="control-label" for="basicinput">Security charge</label>
<div class="controls">
<input type="text"    name="securitycharge"  placeholder="Enter Product Price" class="span8 tip" required maxlength="3">
</div>
</div>


<div class="control-group">
<label class="control-label" for="basicinput">Product Description</label>
<div class="controls">
<textarea  name="productDescription"  placeholder="Enter Product Description" rows="6" class="span8 tip" maxlength="20">
</textarea>  
</div>
</div>

<div class="control-group">
<label class="control-label" for="basicinput">quantity</label>
<div class="controls">
<input type="text"    name="quantity"  placeholder="Enter Product quntity" class="span8 tip" required maxlength="1">
</div>
</div>

<div class="control-group">
<label class="control-label" for="basicinput">Product Availability</label>
<div class="controls">
<select   name="productAvailability"  id="productAvailability" class="span8 tip" required>
<option value="">Select</option>
<option value="In Stock">In Stock</option>
<option value="Out of Stock">Out of Stock</option>
</select>
</div>
</div>



<div class="control-group">
<label class="control-label" for="basicinput">Product Image1</label>
<div class="controls">
<input type="file" name="productimage1" id="productimage1" value="" class="span8 tip" required>
</div>
</div>


<div class="control-group">
<label class="control-label" for="basicinput">Product Image2</label>
<div class="controls">
<input type="file" name="productimage2"  class="span8 tip" required>
</div>
</div>



<div class="control-group">
<label class="control-label" for="basicinput">Product Image3</label>
<div class="controls">
<input type="file" name="productimage3"  class="span8 tip">
</div>
</div>
 <div class="row">
     <button> <input type="submit" name="submit" value="Submit"></button>
    </div>

</div>
	
									</form>
							</div>
						</div>


	
						
						
					</div><!--/.content-->
				</div><!--/.span9-->
			</div>
		</div><!--/.container-->
	</div><!--/.wrapper-->
         

			
	

	<script src="script.js"></script>
</body>
</html>