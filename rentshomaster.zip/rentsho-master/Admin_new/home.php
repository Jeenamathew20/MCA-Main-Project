
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="style.css">

	<title>AdminHub</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-building-house'></i>
			<span class="text">Rentsho-Master</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="home.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Admin Dashboard</span>
				</a>
			</li>
			<div class="span3">
					<div class="sidebar">


<ul class="widget widget-menu unstyled">
	
<li class="dropdown">
		<!--<a class="nav-link menu-title active" href="#"><span>Order Management</span></a>
		<ul class="nav-submenu menu-content"style=display: block;">
		<li><a href="#" class="active">Today Offer</a></li>
		<li><a href="#" class="">delivered Order</a></li>
		<li><a href="#" class="">pendin</a></li>

</ul></li>
			<li>-->
			
					
        
			
  <!-- <a class="collapsed"  data-toggle="collapse"  href="#togglePages">
  <i class='bx bxs-user-circle'></i>
<i class='icon-chevron-down pull-right'></i>
	<i class="icon-chevron-up pull-right"></i><span class="text">
					Order Management</span></a>
					<ul id="togglePages" class="collapse unstyled"></ul>
									<li>
										<a href="todays-orders.php">
											<i class="bx bx-arch"></i>
											Today's Orders
											

											 
											<b class="label orange pull-right"></b>
</a>

</li>

<li>
										<a href="pending-orders.php">
											<i class="bx bx-arch"></i>
											Pending Orders
											<b class="label orange pull-right"></b>
											</a>
									</li>
								<li>
								<a href="deliverd-orders.php">
											<i class="bx bx-arch"></i>
											Delivered Orders
											<b class="label orange pull-right"></b>	
												</a>
									</li>

							


</ul>
</div>
</div>								
</div> -->


            
			<li>
				<a href="manage-users.php">
					<i class='bx bxs-user-circle' ></i>
					<span class="text">Manage Users</span>
				</a>

			</li>
            <li>
				<a href="category.php">
					<i class='bx bx-arch' ></i>
					<span class="text">Create Categories</span>
				</a>
			</li>
			<!-- <li>
				<a href="subcategory.php">
					<i class='bx bx-arch' ></i>
					<span class="text">Sub Categories</span>
				</a>
			</li> -->
			<li>
				<a href="insert-product.php">
					<i class='bx bxs-traffic-cone' ></i>
					<span class="text">Insert Product</span>
				</a>
			</li>
			<!-- <li>
				<a href="manage-product.php">
					<i class='bx bxs-message-dots' ></i>
					<span class="text">Manage product</span>
				</a>
			</li> -->
            <li>
				<a href="lender-logs.php">
					<i class='bx bx-arch' ></i>
					<span class="text">Lender Management</span>
				</a>
			</li>
            <li>
				<a href="user-logs.php">
					<i class='bx bx-arch' ></i>
					<span class="text">User Login Log</span>
				</a>
			</li>

			<li>
			<li>
		
		<ul class="side-menu">
			</li>
			<li>
				<a href="../login.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>

	</section>-->
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<!-- <a href="#" class="nav-link">Categories</a> -->
			<!-- <form action="#">
				<div class="form-input">
					<input type="search" placeholder="Search...">
					<button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
				</div> -->
			</form>
			<input type="checkbox" id="switch-mode" hidden>
			<label for="switch-mode" class="switch-mode"></label>
			<!--<a href="#" class="notification">
				<i class='bx bxs-bell' ></i>
				<span class="num">8</span>
			</a>-->
			<!-- <a href="#" class="profile">
				<img src="images/admin.jpg">
			</a> -->
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Dashboard </h1>
					<ul class="breadcrumb">
						<li>
							<a href="home.php">Dashboard</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="home.php">Home</a>
						</li>
					</ul>
				</div>
				<!-- <a href="#" class="btn-download"> 
					<i class='bx bxs-cloud-download' ></i>
					<span class="text">Download PDF</span>
				</a> -->
			</div>
         

			<div class="table-data">
				<div class="order">
					<div class="head">
					<a href="rentproducts.php"><h3>Rent products</h3></a>
						
					</div>
					
				</div>
				
			</div>
			<div class="table-data">
				<div class="order">
					<div class="head">
					
						<a href="stock.php"><h3>Stock Mnagement</h3></a>
					
					</div>
					
				</div>
				
			<div class="table-data">
				<div class="order">
					<div class="head">
					<a href="adddeliveryboy.php"><h3>Add delivery boy</h3></a>
						
					</div>
					
				</div>
				
			</div>
			<div class="table-data">
				<div class="order">
					<div class="head">
					
						<a href="productreview.php"	><h3>View Reviews</h3></a>
					
					</div>
					
				</div>
		</main>
	</section>
	

	<script src="script.js"></script>
</body>
</html>