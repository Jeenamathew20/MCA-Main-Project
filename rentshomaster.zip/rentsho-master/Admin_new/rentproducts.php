<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="tablestyle.css">

	<title>AdminHub</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-building-house'></i>
			<span class="text">Rentsho-Master</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="home.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Admin Dashboard</span>
				</a>
			</li>
			<div class="span3">
					<div class="sidebar">


<ul class="widget widget-menu unstyled">
	
<li class="dropdown">
		<!--<a class="nav-link menu-title active" href="#"><span>Order Management</span></a>
		<ul class="nav-submenu menu-content"style=display: block;">
		<li><a href="#" class="active">Today Offer</a></li>
		<li><a href="#" class="">delivered Order</a></li>
		<li><a href="#" class="">pendin</a></li>

</ul></li>
			<li>-->
			
					
        
			
  <a class="collapsed"  data-toggle="collapse"  href="#togglePages">
  <i class='bx bxs-user-circle'></i>
<i class='icon-chevron-down pull-right'></i>
	<i class="icon-chevron-up pull-right"></i><span class="text">
					Order Management</span></a>
					<ul id="togglePages" class="collapse unstyled"></ul>
									<li>
										<a href="todays-orders.php">
											<i class="bx bx-arch"></i>
											Today's Orders
											

											 
											<b class="label orange pull-right"></b>
</a>

</li>

<li>
										<a href="pending-orders.php">
											<i class="bx bx-arch"></i>
											Pending Orders
											<b class="label orange pull-right"></b>
											</a>
									</li>
								<li>
								<a href="deliverd-orders.php">
											<i class="bx bx-arch"></i>
											Delivered Orders
											<b class="label orange pull-right"></b>	
												</a>
									</li>

							


</ul>
</div>
</div>								
</div>


            
			<li>
				<a href="manage-users.php">
					<i class='bx bxs-user-circle' ></i>
					<span class="text">Manage Users</span>
				</a>

			</li>
            <li>
				<a href="category.php">
					<i class='bx bx-arch' ></i>
					<span class="text">Create Categories</span>
				</a>
			</li>
			
			<li>
				<a href="insert-product.php">
					<i class='bx bxs-traffic-cone' ></i>
					<span class="text">Insert Product</span>
				</a>
			</li>
			<!-- <li>
				<a href="manage-product.php">
					<i class='bx bxs-message-dots' ></i>
					<span class="text">Manage product</span>
				</a>
			</li> -->
            <li>
				<a href="lender-logs.php">
					<i class='bx bx-arch' ></i>
					<span class="text">Lender Management</span>
				</a>
			</li>
            <li>
				<a href="user-logs.php">
					<i class='bx bx-arch' ></i>
					<span class="text">User Login Log</span>
				</a>
			</li>

			<li>
			<li>
		
		<ul class="side-menu">
			</li>
			<li>
				<a href="../login.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>

	</section>-->
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<!-- <a href="#" class="nav-link">Categories</a> -->
			<form action="#">
				<div class="form-input">
					<input type="search" placeholder="Search...">
					<button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
				</div>
			</form>
			<input type="checkbox" id="switch-mode" hidden>
			<label for="switch-mode" class="switch-mode"></label>
			<!--<a href="#" class="notification">
				<i class='bx bxs-bell' ></i>
				<span class="num">8</span>
			</a>-->
		
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Dashboard </h1>
					<ul class="breadcrumb">
						<li>
							<a href="home.php">Dashboard</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="home.php">Home</a>
						</li>
					</ul>
				</div>
				<!-- <a href="#" class="btn-download"> 
					<i class='bx bxs-cloud-download' ></i>
					<span class="text">Download PDF</span>
				</a> -->
			</div>
         

			<div class="table-data">
				<div class="order">
					<div class="head">
					<a href="home.php"><h3>Rent products</h3></a>
						
					</div>
					
				</div>
				
			</div>
            <div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Manage User </h3>
					</div>
					<div class="module-body">
	
							
								<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" width="100%">
									<thead>
										<tr>

											<th>Product Name</th>
											<th>product rent</th>
											<th> productdescription</th>
                                            <th> product image 1 </th>
                                            <th> product image 2</th>
											<th>commission</th>
                                            <th>Return date</th>
											<th>Actions</th>
										
										</tr>
									</thead>
									<tbody>
                        <?php
                        include "include/config.php";
                        $sql = "SELECT * FROM `l_product` where commission >= 100";
                        $result = $con->query($sql);
                         if ($result->num_rows > 0) {
                          while($row = $result->fetch_assoc()) {?>
                        <tr class="table-info">
                          <td> <?php echo $row["productname"]; ?>  </td>
                          <td> <?php echo $row["productrent"]; ?> </td>
						  <td> <?php echo $row["productdescription"]; ?>  </td>
						  <td><a href="#"><img src="../Lender/productimages/1/<?php echo $row["productimage1"]; ?>"height="80" width="60"> </td>
						  <td><a href="#"><img src="../Lender/productimages/1/<?php echo $row["productimage2"]; ?>"height="80" width="60">  </td>
						  
						  <td> <?php echo $row["commission"]; ?>  </td>
						  <td> <?php echo $row["returndate"]; ?>  </td>

                          <style type="text/css">
                            .pending{
                              background-color: yellow;
                              padding: 10px;
                              outline: none;
                              border-style: none;
                              border-radius: 5px;
                            }
                            .approved{
                              background-color: green;
                              padding: 10px;
                              outline: none;
                              border-style: none;
                              border-radius: 5px;
                            }
                            .rejected{
                              background-color: skyblue;
                              padding: 10px;
                              outline: none;
                              border-style: none;
                              border-radius: 5px;
                            }
                            .verify{
                              background-color: skyblue;
                              padding: 10px;
                              outline: none;
                              border-style: none;
                              border-radius: 5px;
                            }
                          </style>

                          <?php
                            $status = $row['status'];
                            if($status=='pending'){
                          ?>
                            
                            <td> <button class="approved">Approved</button> </td>
                          <?php
                            }elseif($status=='reject'){
                          ?>
                            <td> <button class="rejected">Rejected</button> </td>
                          <?php
                            }elseif($status=='verify'){
                          ?>
                            
                          <?php
                            }
                          ?>

                          
                          
                          <td>    
                           <form action="" method="post">
                            <input type="hidden" name="lp_id" value="<?php echo $row['lp_id'] ?>">
                            <button type="submit" name="approve" class="btn-success btn" style="background-color: green">APPROVE</button>
                            <button type="submit" name="reject" class="btn-success btn" style="background-color: yellow">REJECT</button>
							
                            
                          
                          </form>
						  <form method="post" action="generate_pdf.php">
						  <button type="submit" name="report" class="btn-success btn" style="background-color: red">Report</button>
						</form>
                        </td>
                        </tr>
                      <?php
                    }}?>
                    <?php
$date = DateTime::createFromFormat('j-M-Y', '1-Feb-2022');
echo $date->format('Y-m-d');
?>
<script>


function stateHandle() {
    if(document.querySelector(".input").value === "") {
        button.disabled = true;
    } else {
        button.disabled = false;
    }
}
<?php
     require("include/config.php");
     if(isset($_POST['approve']))
     {
      $lp_id = $_POST['lp_id'];
        $sql = "UPDATE `l_product` SET `status`='approved' WHERE `lp_id`='$lp_id'  ";
         
         
        if( $con->query($sql)===TRUE )
        {
    
        echo "<script>alert('Approved')</script>";

        }
      }
                
    ?>
<?php
     require("include/config.php");
     if(isset($_POST['reject']))
     {
      $lp_id = $_POST['clp_id'];
        $sql = "UPDATE `l_product` SET `status`='reject' WHERE `lp_id`='$lp_id'  ";
         
         
        if( $con->query($sql)===TRUE )
        {
    
        echo "<script>alert('Rejected')</script>";

        }
      }
                
    ?>
</script>
                      </tbody>
							</div>
						</div>						

		
		</main>
	</section>
	

	<script src="script.js"></script>
</body>
</html>