<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="tablestyle.css">

	<title>AdminHub</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-building-house'></i>
			<span class="text">Rentsho-Master</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="home.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Admin Dashboard</span>
				</a>
			</li>
			<div class="span3">
					<div class="sidebar">


<ul class="widget widget-menu unstyled">
	
<li class="dropdown">
		<!--<a class="nav-link menu-title active" href="#"><span>Order Management</span></a>
		<ul class="nav-submenu menu-content"style=display: block;">
		<li><a href="#" class="active">Today Offer</a></li>
		<li><a href="#" class="">delivered Order</a></li>
		<li><a href="#" class="">pendin</a></li>

</ul></li>
			<li>-->
			
					
        
			
  <a class="collapsed"  data-toggle="collapse"  href="#togglePages">
  <i class='bx bxs-user-circle'></i>
<i class='icon-chevron-down pull-right'></i>
	<i class="icon-chevron-up pull-right"></i><span class="text">
					Order Management</span></a>
					<ul id="togglePages" class="collapse unstyled"></ul>
									<li>
										<a href="todays-orders.php">
											<i class="bx bx-arch"></i>
											Today's Orders
											

											 
											<b class="label orange pull-right"></b>
</a>

</li>

<li>
										<a href="pending-orders.php">
											<i class="bx bx-arch"></i>
											Pending Orders
											<b class="label orange pull-right"></b>
											</a>
									</li>
								<li>
								<a href="deliverd-orders.php">
											<i class="bx bx-arch"></i>
											Delivered Orders
											<b class="label orange pull-right"></b>	
												</a>
									</li>
									<li>
								<a href="updateorder.php">
											<i class="bx bx-arch"></i>
										  Update Orders
											<b class="label orange pull-right"></b>	
												</a>
									</li>

							


</ul>
</div>
</div>								
</div>


            
			
          
			
		
			<li>
				<a href="manage-product.php">
					<i class='bx bxs-message-dots' ></i>
					<span class="text">Manage product</span>
				</a>
			

			<li>
			<li>
		
		<ul class="side-menu">
			</li>
			<li>
				<a href="../login.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>

	</section>-->
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<!-- <a href="#" class="nav-link">Categories</a> -->
			<form action="#">
				<div class="form-input">
					<input type="search" placeholder="Search...">
					<button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
				</div>
			</form>
			<input type="checkbox" id="switch-mode" hidden>
			<label for="switch-mode" class="switch-mode"></label>
			<!--<a href="#" class="notification">
				<i class='bx bxs-bell' ></i>
				<span class="num">8</span>
			</a>-->
			<a href="#" class="profile">
				<img src="images/admin.jpg">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Dashboard </h1>
					<ul class="breadcrumb">
						<li>
							<a href="home.php">Dashboard</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="home.php">Home</a>
						</li>
					</ul>
				</div>
				<!-- <a href="#" class="btn-download"> 
					<i class='bx bxs-cloud-download' ></i>
					<span class="text">Download PDF</span>
				</a> -->
			</div>
         

			<div class="table-data">
				<div class="order">
					<div class="head">
					<a href="home.php"><h3> stock Management</h3></a>
						
					</div>
					
				</div>
				
			</div>
            <div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Stock Details </h3>
					</div>
					<div class="module-body">
	
                    <table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" width="100%">
									<thead>
										<tr>
										<th>Category</th>
											<th>Product Name</th>
											<th>Product Company</th>
											<th>Product Price After Discount(rent Price)</th>
											<th> productdescription</th>
											<th>Security charge</th>
											<th>Product Availability</th>
                                            <th> product image 1 </th>
                                            <th> product image 2</th>
											<th> product image 2</th>
									        <th>Actions</th>
										
										</tr>
									</thead>
									<tbody>
                        <?php
                        include "include/config.php";
                        $sql = "SELECT * FROM `products`";
                        $result = $con->query($sql);
                         if ($result->num_rows > 0) {
                          while($row = $result->fetch_assoc()) {?>
                        <tr class="table-info">
						<td> <?php echo $row["category"]; ?>  </td>	
                          <td> <?php echo $row["productName"]; ?>  </td>
                          <td> <?php echo $row["productCompany"]; ?> </td>
                          <td> <?php echo $row["productPrice"]; ?> </td>
                         <td> <?php echo $row["productDescription"]; ?>  </td>
                          <td> <?php echo $row["securitycharge"]; ?> </td>
                          <td> <?php echo $row["productAvailability"]; ?> </td>
                      
						  <td><a href="#"><img src="Admin_new/productimages/<?php echo $row["productimage1"]; ?>"height="80" width="60"> </td>
						  <td><a href="#"><img src="Admin_new/productimages/<?php echo $row["productimage2"]; ?>"height="80" width="60">  </td>
						  <td><a href="#"><img src="Admin_new/productimages/<?php echo $row["productimage3"]; ?>"height="80" width="60">  </td>
						

                          <style type="text/css">
                            .pending{
                              background-color: yellow;
                              padding: 10px;
                              outline: none;
                              border-style: none;
                              border-radius: 5px;
                            }
                            .approved{
                              background-color: green;
                              padding: 10px;
                              outline: none;
                              border-style: none;
                              border-radius: 5px;
                            }
                            .rejected{
                              background-color: skyblue;
                              padding: 10px;
                              outline: none;
                              border-style: none;
                              border-radius: 5px;
                            }
                            .verify{
                              background-color: skyblue;
                              padding: 10px;
                              outline: none;
                              border-style: none;
                              border-radius: 5px;
                            }
                          </style>

                          
                          
                          <td>    
                           
							
                            
                          
                         
						  <form method="post" action="generate_pdf1.php">
						  <button type="submit" name="report" class="btn-success btn" style="background-color: red">Report</button>
						</form>
                        </td>
                        </tr>
                      <?php
                    }}
                    ?>
                   


</script>
                      </tbody>
							</div>
						</div>						

		
		</main>
	</section>
	

	<script src="script.js"></script>
</body>
</html>