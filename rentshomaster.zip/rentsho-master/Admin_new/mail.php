<?php

include('include/config.php');
use PHPMailer\PHPMailer\PHPMailer; 
use PHPMailer\PHPMailer\Exception; 
if(isset($_POST['submit']))
{
	// $fname=$_POST['fname'];
	// $lname=$_POST['lname'];
    // $gender=$_POST['gender'];
	$email=$_POST['email'];
	// $contact=$_POST['contact'];
	$uname=$_POST['uname'];
	$password=$_POST['password'];


if($con->query( $sql)===TRUE)
{
    require 'PHPMailer1/src/Exception.php'; 
    require 'PHPMailer1/src/PHPMailer.php'; 
    require 'PHPMailer1/src/SMTP.php'; 
     
$mail = new PHPMailer; 
 
$mail->isSMTP();                      // Set mailer to use SMTP 
$mail->Host = 'smtp.gmail.com';       // Specify main and backup SMTP servers 
$mail->SMTPAuth = true;               // Enable SMTP authentication 
$mail->Username = 'rentshomaster@gmail.com';   // SMTP username 
$mail->Password = 'viodqdsxqfxenbny';   // SMTP password 
$mail->SMTPSecure = 'tls';            // Enable TLS encryption, `ssl` also accepted 
$mail->Port = 587;                    // TCP port to connect to 
 
// Sender info 
$mail->setFrom('rentshomaster@gmail.com', 'rentshop'); 
// $mail->addReplyTo('reply@codexworld.com', 'CodexWorld'); 
 
// Add a recipient 
$mail->addAddress($email); 
 
//$mail->addCC('cc@example.com'); 
//$mail->addBCC('bcc@example.com'); 
 
// Set email format to HTML 
$mail->isHTML(true); 
 
// Mail subject 
$mail->Subject = 'rentshop'; 
 
// Mail body content 

$bodyContent .= '<html>
<head>
<meta charset="utf-8">
</head>

<body background="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS4hVvyxHSVWVWGu8Uqq1bOi0x7KAhUG22svA&usqp=CAU" style="background-size: cover;">
    <center>
<h1 style="margin-top: 50px;">Welcome to <b style="color:crimson;">rentshop/b></h1>
<p>Hai,</p>
<p>Your new account with rentshop is ready </p>
Below given is your account details <br>
<table border="1" style="margin-top:30px">
  <tr>
    <th scope="row">Mail From</th>
    <td>rentshop Admin</td>
  </tr>
  <tr>
    <th scope="row">Username</th>
    <td>'.$uname.' </td>
  </tr>
  <tr>
  <th scope="row">password</th>
  <td>'.$password.'</td>
</tr>
</table>
<div style="margin-top:30px">
Explore from here--->> <button onclick="window.location.href="http://localhost/KERALA%20STATE%20ELECTRICITY%20BOARD/colorlib-regform-1/Login_v4/KLogin.php""> KSEB Account</button></div>
</center>
</body>
</html>'; 

$mail->Body    = $bodyContent; 
 
// Send email 
if(!$mail->send()) { 
    echo 'Message could not be sent. Mailer Error: '.$mail->ErrorInfo; 
} else { 
    echo 'Message has been sent.'; 
} 

  echo "<script>alert('saved')</script>";

}
// else{
//   echo "error:" . $sql ."<br>" . $conn->error;
// }
}


?>
