<?php
session_start();
include('include/config.php');
// if(strlen($_SESSION['alogin'])==0)
// 	{	
// header('location:../login.php');
// }
// else{

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="style.css">

	<title>AdminHub</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-building-house'></i>
			<span class="text">Rentsho-Master</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="home.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Admin Dashboard</span>
				</a>
			</li>
            <li>
				<a href="change-password.php">
					<i class='bx bxs-user-circle' ></i>
					<span class="text">Order Management</span>
				</a>
			</li>
            
			<li>
				<a href="manage-users.php">
					<i class='bx bxs-user-circle' ></i>
					<span class="text">Manage Users</span>
				</a>
			</li>
            <li>
				<a href="category.php">
					<i class='bx bx-arch' ></i>
					<span class="text">Create Categories</span>
				</a>
			</li>
			<li>
				<a href="subcategory.php">
					<i class='bx bx-arch' ></i>
					<span class="text">Sub Categories</span>
				</a>
			</li>
			<li>
				<a href="insert-product.php">
					<i class='bx bxs-traffic-cone' ></i>
					<span class="text">Insert Product</span>
				</a>
			</li>
			<li>
				<a href="manage-product.php">
					<i class='bx bxs-message-dots' ></i>
					<span class="text">Manage product</span>
				</a>
			</li>
            <li>
				<a href="lender-logs.php">
					<i class='bx bx-arch' ></i>
					<span class="text">Lender Management</span>
				</a>
			</li>
            <li>
				<a href="user-logs.php">
					<i class='bx bx-arch' ></i>
					<span class="text">User Login Log</span>
				</a>
			</li>

			<li>
			<li>
		</ul>
		<ul class="side-menu">
			</li>
			<li>
				<a href="logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<!-- <a href="#" class="nav-link">Categories</a> -->
			<form action="#">
				<div class="form-input">
					<input type="search" placeholder="Search...">
					<button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
				</div>
			</form>
			<input type="checkbox" id="switch-mode" hidden>
			<label for="switch-mode" class="switch-mode"></label>
			<!--<a href="#" class="notification">
				<i class='bx bxs-bell' ></i>
				<span class="num">8</span>
			</a>-->
			<a href="#" class="profile">
				<img src="images/admin.jpg">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Dashboard </h1>
					<ul class="breadcrumb">
						<li>
							<a href="home.php">Dashboard</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="home.php">Home</a>
						</li>
					</ul>
				</div>
				<!-- <a href="#" class="btn-download"> 
					<i class='bx bxs-cloud-download' ></i>
					<span class="text">Download PDF</span>
				</a> -->
			</div>
         

           
            <div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Manage User </h3>
					</div>
					<div class="module-body">
	
							
								<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" width="100%">
									<thead>
										<tr>
											<th>#</th>
											<th> Name</th>
											<th> User Email</th>
											<th> contact number</th>
											<th>Address</th>
										
										</tr>
									</thead>
									<tbody>

<?php $query=mysqli_query($con,"select * FROM users where u_type='lender';");
$cnt=1;
while($row=mysqli_fetch_array($query))
{
?>									
										<tr>
											<td><?php echo htmlentities($cnt);?></td>
											<td><?php echo htmlentities($row['name']);?></td>
											<td><?php echo htmlentities($row['email']);?></td>
											<td> <?php echo htmlentities($row['contactno']);?></td>
											<td><?php echo htmlentities($row['shippingAddress']); ?></td>
									
											
										<?php $cnt=$cnt+1; }//} ?>
										
								</table>
							</div>
						</div>						

			</div>
		</main>
	</section>
	

	<script src="script.js"></script>
</body>
</html>