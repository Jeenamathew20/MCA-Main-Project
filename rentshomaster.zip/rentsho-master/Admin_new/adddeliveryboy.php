
<?php
   session_start();
   include('include/config.php');
   use PHPMailer\PHPMailer\PHPMailer; 
   use PHPMailer\PHPMailer\Exception; 
   if(isset($_POST['submit'])){

	$email=$_POST['email'];
	// $contact=$_POST['contact'];
	$uname=$_POST['uname'];
	$password=$_POST['password'];
	$sql="insert into adddeliveryboy(fname,lname,gender,email,contact,uname,password) values('$_POST[fname]','$_POST[lname]','$_POST[gender]','$_POST[email]','$_POST[contact]','$_POST[uname]','$_POST[password]')";
 if( $con->query( $sql)===TRUE )
 {
	require 'PHPMailer/src/Exception.php'; 
    require 'PHPMailer/src/PHPMailer.php'; 
    require 'PHPMailer/src/SMTP.php'; 
	$mail = new PHPMailer; 
 
	$mail->isSMTP();                      // Set mailer to use SMTP 
	$mail->Host = 'smtp.gmail.com';       // Specify main and backup SMTP servers 
	$mail->SMTPAuth = true;               // Enable SMTP authentication 
	$mail->Username = 'rentshomaster@gmail.com';   // SMTP username 
	$mail->Password = 'ahqgglpfhtrsqzyk';   // SMTP password 
	$mail->SMTPSecure = 'tls';            // Enable TLS encryption, `ssl` also accepted 
	$mail->Port = 587;                    // TCP port to connect to 
	 
	// Sender info 
	$mail->setFrom('rentshomaster@gmail.com', 'rentshop'); 
	// $mail->addReplyTo('reply@codexworld.com', 'CodexWorld'); 
	 
	// Add a recipient 
	$mail->addAddress($email); 
	 
	//$mail->addCC('cc@example.com'); 
	//$mail->addBCC('bcc@example.com'); 
	 
	// Set email format to HTML 
	$mail->isHTML(true); 
	 
	// Mail subject 
	$mail->Subject = 'rentshop'; 
	 
	// Mail body content 
	
	$bodyContent .= '<html>
	<head>
	<meta charset="utf-8">
	</head>
	
	<body background="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS4hVvyxHSVWVWGu8Uqq1bOi0x7KAhUG22svA&usqp=CAU" style="background-size: cover;">
		<center>
	<h1 style="margin-top: 50px;">Welcome to <b style="color:crimson;">Rentshomaster</b></h1>
	<p>Hai,</p>
	<p>Your new account with rentshop is ready </p>
	Below given is your account details <br>
	<table border="1" style="margin-top:30px">
	  <tr>
		<th scope="row">Mail From</th>
		<td>rentshop Admin</td>
	  </tr>
	  <tr>
		<th scope="row">Username</th>
		<td>'.$uname.' </td>
	  </tr>
	  <tr>
	  <th scope="row">password</th>
	  <td>'.$password.'</td>
	</tr>
	</table>

	</center>
	</body>
	</html>'; 
	
	$mail->Body    = $bodyContent; 
	 
	// Send email 
	if(!$mail->send()) { 
		echo 'Message could not be sent. Mailer Error: '.$mail->ErrorInfo; 
	} else { 
		echo 'Message has been sent.'; 
	} 
	
	  echo "<script>alert('saved')</script>";
	
	}
 
 
 
 else{
   echo "error:" . $sql ."<br>" . $con->error;
 }
 }
 ?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="style.css">

	<title>AdminHub</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-building-house'></i>
			<span class="text">Rentsho-Master</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="home.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Admin Dashboard</span>
				</a>
			</li>
            <li>
				<a href="change-password.php">
					<i class='bx bxs-user-circle' ></i>
					<span class="text">Order Management</span>
				</a>
			</li>
            
			<li>
				<a href="manage-users.php">
					<i class='bx bxs-user-circle' ></i>
					<span class="text">Manage Users</span>
				</a>
			</li>
            <li>
				<a href="category.php">
					<i class='bx bx-arch' ></i>
					<span class="text">Create Categories</span>
				</a>
			</li>
			<!-- <li>
				<a href="subcategory.php">
					<i class='bx bx-arch' ></i>
					<span class="text">Sub Categories</span>
				</a>
			</li> -->
			<li>
				<a href="insert-product.php">
					<i class='bx bxs-traffic-cone' ></i>
					<span class="text">Insert Product</span>
				</a>
			</li>
			<!-- <li>
				<a href="manage-product.php">
					<i class='bx bxs-message-dots' ></i>
					<span class="text">Manage product</span>
				</a>
			</li> -->
            <li>
				<a href="lender-logs.php.php">
					<i class='bx bx-arch' ></i>
					<span class="text">Lender Management</span>
				</a>
			</li>
            <li>
				<a href="user-logs.php.php">
					<i class='bx bx-arch' ></i>
					<span class="text">User Login Log</span>
				</a>
			</li>

			<li>
			<li>
		</ul>
		<ul class="side-menu">
			</li>
			<li>
				<a href="logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<!-- <a href="#" class="nav-link">Categories</a> -->
			<form>
				<div class="form-input">
					<input type="search" placeholder="Search...">
					<button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
				</div>
			</form>
			<input type="checkbox" id="switch-mode" hidden>
			<label for="switch-mode" class="switch-mode"></label>
			<!--<a href="#" class="notification">
				<i class='bx bxs-bell' ></i>
				<span class="num">8</span>
			</a>-->
			<a href="#" class="profile">
				<img src="images/admin.jpg">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Dashboard </h1>
					<ul class="breadcrumb">
						<li>
							<a href="home.php">Dashboard</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="home.php">Home</a>
						</li>
					</ul>
				</div>
				<!-- <a href="#" class="btn-download"> 
					<i class='bx bxs-cloud-download' ></i>
					<span class="text">Download PDF</span>
				</a> -->
			</div>
            
			
                  <div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Add Delivery Boy</h3>
					</div>
							<div class="module-body">

									
			
 
			<form class="form-horizontal row-fluid" name="insertproduct" method="post" enctype="multipart/form-data">






			<div class="container">
			<form action="adddeliveryboy.php" method="post">
				<!-- <form> -->
  <link rel="stylesheet" href="s1.css">
    <div class="row">
      <div class="col-25">
        <label for="fname">First Name</label>
      </div>
      <div class="col-75">
        <input type="text" id="fname" name="fname" placeholder="Your name.." required>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="lname">Last Name</label>
      </div>
      <div class="col-75">
        <input type="text" id="lname" name="lname" placeholder="Your last name.." required>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="gender">Gender</label>
      </div>
      <div class="col-75">
        <select id="gender" name="gender">
          <option value="female">female</option>
          <option value="male">male</option>
          <option value="other">other</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="email">Email</label>
      </div>
      <div class="col-75">
        <input type="text" id="email" name="email" placeholder="Your emai.." required>
      </div>
    </div>
	<div class="row">
      <div class="col-25">
        <label for="contact">contact</label>
      </div>
      <div class="col-75">
        <input type="text" id="contact" name="contact" placeholder="Your phone number.." maxlength="10" pattern="[7-9]{1}[0-9]{9}">
      </div>
    </div>
	<div class="row">
      <div class="col-25">
        <label for="uname">User Name</label>
      </div>
      <div class="col-75">
        <input type="text" id="uname" name="uname" placeholder="enter user name.." required>
      </div>
    </div>
	<div class="row">
      <div class="col-25">
        <label for="password">Password</label>
      </div>
      <div class="col-75">
        <input type="text" id="password" name="password" placeholder="password.." required>
      </div>
    </div>
    <div class="row">
     <input type="submit" name="submit" value="Submit">
    </div>
  </form>
</div>
						
						
					</div><!--/.content-->
				</div><!--/.span9-->
			</div>
		</div><!--/.container-->
	</div><!--/.wrapper-->
         

			
	

	<script src="script.js"></script>
</body>
</html>
